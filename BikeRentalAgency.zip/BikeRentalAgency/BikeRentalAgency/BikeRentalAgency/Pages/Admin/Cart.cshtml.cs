using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BikeRentalAgency.Infrastructure;
using BikeRentalAgency.Models;
using System.Linq;
namespace BikeRentalAgency.Pages
{
    public class CartModel : PageModel
    {
        private IAgencyRepository repository;
        public CartModel(IAgencyRepository repo, Cart cartService)
        {
            repository = repo;
            Cart = cartService;
        }
        public Cart Cart { get; set; }
        public string ReturnUrl { get; set; }
        public void OnGet(string returnUrl)
        {
            ReturnUrl = returnUrl ?? "/";

        }
        public IActionResult OnPost(long bikeId, string returnUrl)
        {
            Bike bike = repository.Bike.FirstOrDefault(p => p.BikeId == bikeId);
            Cart.AddItem(bike, 1);
            return RedirectToPage(new { returnUrl = returnUrl });
        }
        public IActionResult OnPostRemove(long bikeId, string returnUrl)
        {
            Cart.RemoveLine(Cart.Lines.First(cl => cl.Bike.BikeId == bikeId).Bike);
            return RedirectToPage(new { returnUrl = returnUrl });
        }
    }
}