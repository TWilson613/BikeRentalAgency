﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeRentalAgency.Models
{
        public class EFAgencyRepository : IAgencyRepository
        {
            private BikeRentalContext context;
            public EFAgencyRepository(BikeRentalContext ctx)
                {
                    context = ctx;
                }
        public IQueryable<Bike> Bike => Bike;
        public IQueryable<BikesInShop> BikesInShop => context.BikesInShops;
        public IQueryable<BikeType> BikeType => context.BikeTypes;
        public IQueryable<Customer> Customer => context.Customers;
        public IQueryable<Employee> Employee => context.Employees;
        public IQueryable<PaymentStatus> PaymentStatus => context.PaymentStatuses;
        public IQueryable<Rental> Rental => context.Rentals;
        public IQueryable<RentalDetail> RentalDetail => context.RentalDetails;
        public IQueryable<RentalRate> RentalRate => context.RentalRates;
        public IQueryable<Shop> Shop => context.Shops;
        public IQueryable<SpecialFeature> SpecialFeature => context.SpecialFeatures;

        public IQueryable<BikesInShop> BikesInShops => throw new NotImplementedException();

        IQueryable<PaymentStatus> IAgencyRepository.PaymentStatus => throw new NotImplementedException();

        IQueryable<RentalRate> IAgencyRepository.RentalRate => throw new NotImplementedException();

        IQueryable<RentalDetail> IAgencyRepository.RentalDetail => throw new NotImplementedException();

        IQueryable<Rental> IAgencyRepository.Rental => throw new NotImplementedException();
        public void SaveRental(Rental rental)
        {
            context.SaveChanges();
        }
        public void SaveBike(Bike b)
        {
            context.SaveChanges();
        }
        public void CreateBike(Bike b)
        {
            context.Add(b);
            context.SaveChanges();
        }
        public void DeleteBike(Bike b)
        {
            context.Remove(b);
            context.SaveChanges();
        }
    }
    }