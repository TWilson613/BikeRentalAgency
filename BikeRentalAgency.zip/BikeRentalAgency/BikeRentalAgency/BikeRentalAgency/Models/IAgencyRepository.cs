﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeRentalAgency.Models
{
    public interface IAgencyRepository
    {
        IQueryable<Bike> Bike { get; }
        IQueryable<BikesInShop> BikesInShops { get; }
        IQueryable<BikeType> BikeType { get; }
        IQueryable<Customer> Customer { get; }
        IQueryable<Shop> Shop { get; }
        IQueryable<Employee> Employee { get; }
        IQueryable<PaymentStatus> PaymentStatus { get; }
        IQueryable<RentalRate> RentalRate { get; }
        IQueryable<RentalDetail> RentalDetail { get; }
        IQueryable<Rental> Rental { get; }
        void SaveRental(Rental rental);
        void SaveBike(Bike b);
        void CreateBike(Bike b);
        void DeleteBike(Bike b);
    }
}