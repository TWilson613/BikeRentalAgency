﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BikeRentalAgency.Models;

namespace BikeRentalAgency.Models.ViewModels
{
    public class BikesListViewModel
    {
        public IEnumerable<Rental> Rentals { get; set; }
        public PagingInfo PagingInfo { get; set; }
        public string CurrentCategory { get; set; }

    }
}
