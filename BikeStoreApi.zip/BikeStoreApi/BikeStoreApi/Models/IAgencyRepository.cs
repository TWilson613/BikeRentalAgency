﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeStoreApi.Models
{
    public interface IAgencyRepository
    {

        //need of crud
       Task<int> AddCustomer(Customer customer);

        Task<int> DeleteCustomer(int? CustId);
        Task SaveCustomer(Customer customer);

        Task<int> AddBike(Bike bike);
        Task<int> DeleteBike(int? BikeId);
       Task SaveBike(Bike bike);

        Task<int> AddRental(Rental rental);
        Task SaveRental(Rental rental);
        Task<int> DeleteRental(int? rentalID);
        Task<int> AddEmployee(Employee employee);

        Task<int> DeleteEmployee(int? EmployeeId);
        Task SaveEmployee(Employee employee);

        //rentaldetail
        IQueryable<Bike> Bike { get; }
        //what types of things will be needed in a list
        IQueryable<Customer> Customers { get; }
        //
     
    }
}