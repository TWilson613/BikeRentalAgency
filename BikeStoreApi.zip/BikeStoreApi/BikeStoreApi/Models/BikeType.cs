﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BikeStoreApi.Models
{
    public partial class BikeType
    {
        public int TypeId { get; set; }
        public bool MountainBike { get; set; }
        public bool StreetBike { get; set; }
        public bool BeachCruiser { get; set; }
        public bool Moped { get; set; }
        public bool TandemBike { get; set; }
        public bool Unicycle { get; set; }

        public virtual Bike Type { get; set; }
    }
}
