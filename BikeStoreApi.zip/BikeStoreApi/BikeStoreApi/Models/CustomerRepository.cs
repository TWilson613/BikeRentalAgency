﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeStoreApi.Models
{
    public class CustomerRepository
    {
        IQueryable<Bike> Bike { get; }
        IQueryable<BikeType> BikeType { get; }
        IQueryable<PaymentStatus> PaymentStatus { get; }
        IQueryable<RentalDetail> RentalDetail { get; }
        IQueryable<Rental> Rental { get; }
    }
}