﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BikeStoreApi.Models
{
    public partial class SpecialFeature
    {
        public SpecialFeature()
        {
            Bikes = new HashSet<Bike>();
        }

        public int FeatureId { get; set; }
        public bool ElectricMotor { get; set; }
        public bool Basket { get; set; }
        public string Color { get; set; }
        public bool AllTerrain { get; set; }
        public bool ChildSeat { get; set; }

        public virtual ICollection<Bike> Bikes { get; set; }
    }
}
