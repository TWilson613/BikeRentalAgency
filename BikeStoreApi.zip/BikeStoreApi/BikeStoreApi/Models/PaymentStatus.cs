﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BikeStoreApi.Models
{
    public partial class PaymentStatus
    {
        public PaymentStatus()
        {
            Rentals = new HashSet<Rental>();
        }

        public int PaymentStatusCode { get; set; }
        public string PaymentMethod { get; set; }
        public string PaymentStatusDescription { get; set; }

        public virtual ICollection<Rental> Rentals { get; set; }
    }
}
