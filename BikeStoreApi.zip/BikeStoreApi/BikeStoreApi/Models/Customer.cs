﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BikeStoreApi.Models
{
    public partial class Customer
    {
        public Customer()
        {
            Rentals = new HashSet<Rental>();
        }

        public int CustId { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        public virtual ICollection<Rental> Rentals { get; set; }
    }
}
